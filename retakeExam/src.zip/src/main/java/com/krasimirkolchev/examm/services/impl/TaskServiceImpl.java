package com.krasimirkolchev.examm.services.impl;

import com.krasimirkolchev.examm.models.entities.Progress;
import com.krasimirkolchev.examm.models.entities.Task;
import com.krasimirkolchev.examm.models.serviceModels.TaskServiceModel;
import com.krasimirkolchev.examm.repositories.TaskRepository;
import com.krasimirkolchev.examm.services.ClassificationService;
import com.krasimirkolchev.examm.services.TaskService;
import com.krasimirkolchev.examm.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskServiceImpl implements TaskService {
    private final TaskRepository taskRepository;
    private final UserService userService;
    private final ClassificationService classificationService;
    private final ModelMapper modelMapper;

    @Autowired
    public TaskServiceImpl(TaskRepository taskRepository, UserService userService, ClassificationService classificationService, ModelMapper modelMapper) {
        this.taskRepository = taskRepository;
        this.userService = userService;
        this.classificationService = classificationService;
        this.modelMapper = modelMapper;
    }

    @Override
    public TaskServiceModel addTask(TaskServiceModel taskServiceModel) {
        Task task = this.modelMapper.map(taskServiceModel, Task.class);
        task.setClassification(classificationService.getClassificationById(taskServiceModel.getClassification()));
        task.setProgress(Progress.OPEN);

        return this.modelMapper.map(this.taskRepository.save(task), TaskServiceModel.class);
    }

    @Override
    public List<TaskServiceModel> getAllTasks() {
        return this.taskRepository.findAll()
                .stream().map(t -> this.modelMapper.map(t, TaskServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public void changeProgress(String id) {
        Task task = this.taskRepository.getOne(id);

        switch (task.getProgress()) {
            case OPEN:
                task.setProgress(Progress.IN_PROGRESS);
                this.taskRepository.saveAndFlush(task);
                break;
            case IN_PROGRESS:
                task.setProgress(Progress.COMPLETED);
                this.taskRepository.saveAndFlush(task);
                break;
            case COMPLETED:
                this.taskRepository.deleteById(id);
                break;
        }

    }
}
