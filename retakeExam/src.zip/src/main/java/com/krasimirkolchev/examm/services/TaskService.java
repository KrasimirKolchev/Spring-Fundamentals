package com.krasimirkolchev.examm.services;

import com.krasimirkolchev.examm.models.serviceModels.TaskServiceModel;

import java.util.List;

public interface TaskService {

    TaskServiceModel addTask(TaskServiceModel taskServiceModel);

    List<TaskServiceModel> getAllTasks();

    void changeProgress(String id);
}
