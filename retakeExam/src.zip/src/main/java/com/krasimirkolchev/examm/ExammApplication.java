package com.krasimirkolchev.examm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExammApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExammApplication.class, args);
    }

}
