package com.krasimirkolchev.examm.models.entities;

public enum Progress {
    OPEN, IN_PROGRESS, COMPLETED, OTHER
}
